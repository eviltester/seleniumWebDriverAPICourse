In order to use the batch files here, you need to download

http://selenium.googlecode.com/files/selenium-server-standalone-2.25.0.jar

Listed on http://seleniumhq.org/download/

If the version changes from 2.25.0 then download the new selenium-server-standalone-x.xx.x.jar and amend the .bat files to reference the correct version of the jar.